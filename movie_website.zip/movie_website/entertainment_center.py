﻿import fresh_tomatoes
import media

Monster_Hunt = media.Movie("Monster Hunt", "A combination of man and animation",
                        "https://upload.wikimedia.org/wikipedia/zh/f/fd/Monster_Hunt_poster.jpg",
                        "https://www.youtube.com/watch?v=xYqSklqpfpw")

#print (Monster_Hunt.storyline)
#Monster_Hunt.show_trailer()

Planet_of_the_Apes = media.Movie("Planet_of_the_Apes", "A war between man and apes",
                     "https://upload.wikimedia.org/wikipedia/zh/7/77/Dawn_of_the_Planet_of_the_Apes.jpg",
                     "https://www.youtube.com/watch?v=-hM1jW6XCog")
#print (Planet_of_the_Apes.storyline)
#Planet_of_the_Apes.show_trailer()

Life_of_Pi = media.Movie("Life_of_Pi", "A story of a man and his amazing life ",
                        "https://upload.wikimedia.org/wikipedia/zh/c/cf/Life_of_Pi_Poster.jpg",
                        "https://www.youtube.com/watch?v=SEjzQ69yvHg")
#print (Life_of_Pi.storyline)
#Life_of_Pi.show_trailer()

The_Grandmaster = media.Movie("The_Grandmaster", "A story of Wing Chun master",
                        "https://upload.wikimedia.org/wikipedia/zh/c/c9/The_Grand_Masters_poster.jpg",
                        "https://www.youtube.com/watch?v=2Rvb_m3zH8Q")
#print (The_Grandmaster.storyline)
#The_Grandmaster.show_trailer()

Painted_Skin = media.Movie("Painted_Skin", "The story From the Strange Tales",
                        "https://upload.wikimedia.org/wikipedia/zh/b/b0/畫皮.jpg",
                        "https://www.youtube.com/watch?v=KAyNqUw5LNc")
#print (Painted_Skin.storyline)
#Painted_Skin.show_trailer()

The_Lion_King = media.Movie("The_Lion_King", "A story of a lion becoming the king",
                        "https://upload.wikimedia.org/wikipedia/zh/3/3d/The_Lion_King_poster.jpg",
                        "https://www.youtube.com/watch?v=wJWecGz2sTs")
#print (The_Lion_King.storyline)
#The_Lion_King.show_trailer()

movies = [Monster_Hunt, Planet_of_the_Apes, Life_of_Pi, The_Grandmaster, Painted_Skin, The_Lion_King]
fresh_tomatoes.open_movies_page (movies)





